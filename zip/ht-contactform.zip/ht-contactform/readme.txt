=== Contact Form 7 Widget For Elementor Page Builder ===
Contributors: htplugins
Tags: Contact Form, Elementor, Contact Form 7, Contact Form 7 Widget, Elementor Addons
Requires at least: 4.4
Tested up to: 5.5
Stable tag: 1.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Contact Form 7 Widget is a elementor addons for elementor page bulider. It's Help to you easily drag and drop Contact Form 7 forms from a drop down list.
[Required Plugin:  Contact Form 7](https://wordpress.org/plugins/contact-form-7/)

[youtube https://youtu.be/ZRTPsGZnJq4]

> ## Absolute Addons for Elementor Page Builder
> Don't forgete to check our Unlimite mega addon for Elementor page Builder.
> [HT Mega – Absolute Addons for Elementor Page Builder](https://wordpress.org/plugins/ht-mega-for-elementor/)
> Includes 360 Blocke & 15 Landing Pages.

== Features: ==
* Drag and drop the widget
* Custom Styling Options
* Show Contact form in any place on your website.

== Need Help? ==
Is there any feature that you want to get in this plugin? 
Needs assistance to use this plugin? 
Feel free to [Contact us](https://htplugins.com/contact-us/)

== Installation ==
This section describes how to install the Contact Form 7 Widget For Elementor Page Builder Plugins for WordPress get it working.

= 1) Install =

= Install: =
1. Go to the WordPress Dashboard "Add New Plugin" section.
2. Search For "WPForms Widget For Elementor Page Builder".
3. Install, then Activate it.

= OR: =
1. Unzip (if it is zipped) and Upload `ht-contactform` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Screenshots ==
1. Elementor Addons Content Options
2. Elementor Addons Styling Options
3. Front end View